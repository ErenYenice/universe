from flask import Flask, render_template, url_for, request
import pandas as pd
import re
import numpy as np

app = Flask(__name__)

def filter_data(data, universite, program, puan_turu, puan_araligi):
    filtered_data = data.copy()

    if universite:
        filtered_data = filtered_data[filtered_data['Üniversite Adı'] == universite]

    if program:
        filtered_data = filtered_data[filtered_data['Program Adı'].apply(lambda x: x.lower().startswith(program.lower()))]

    if puan_turu:
        filtered_data = filtered_data[filtered_data['Puan Türü'] == puan_turu]

    if puan_araligi:
        puan_araligi = float(puan_araligi)
        filtered_data = filtered_data[(filtered_data['En Küçük Puan'] <= puan_araligi) & (filtered_data['En Büyük Puan'] >= puan_araligi)]

    # Puansız olanlara NaN (Not a Number) değeri atayalım
    filtered_data['En Küçük Puan'] = filtered_data['En Küçük Puan'].replace('--', np.nan)

    return filtered_data

def extract_program_name(program):
    match = re.search(r"^(.*?)\s*\(", program)
    if match:
        return match.group(1)
    return program.strip()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/universiteler')
def universiteler():
    data = pd.read_excel(r'C:\Users\emira\OneDrive\Masaüstü\HTMLdeneme\UniLisans.xlsx')
    universities = data['Üniversite Adı'].unique().tolist()
    return render_template('universiteler.html', universities=universities)

@app.route('/universite_detay/<universite>')
def universite_detay(universite):
    return render_template('universite_detay.html', universite=universite)

@app.route('/taban_puanlari', methods=['GET', 'POST'])
def taban_puanlari():
    data = pd.read_excel(r'C:\Users\emira\OneDrive\Masaüstü\HTMLdeneme\UniLisans.xlsx')

    # Get unique universities list
    universities_list = data['Üniversite Adı'].unique().tolist()

    universite = request.form.get('universite', '')
    program = request.form.get('program', '')
    puan_turu = request.form.get('puan_turu', '')
    puan_araligi = request.form.get('puan_araligi_min', '')

    filtered_data = filter_data(data, universite, program, puan_turu, puan_araligi)

    # Extract unique program names without content inside parentheses
    programs = filtered_data['Program Adı'].apply(extract_program_name).unique().tolist()

    # Puansız olanları ayrı bir DataFrame'e alıyoruz ve NaN (Not a Number) olarak işaretliyoruz
    nan_puanlar = filtered_data[filtered_data['En Küçük Puan'].isna()]

    # Puansızları çıkarıyoruz ve geri kalanları puanlara göre sıralıyoruz
    filtered_data = filtered_data[~filtered_data['En Küçük Puan'].isna()]
    filtered_data['En Küçük Puan'] = filtered_data['En Küçük Puan'].astype(float)
    filtered_data = filtered_data.sort_values(by=['Puan Türü', 'En Küçük Puan'], ascending=[False, False])

    # Puansızları tekrar ekliyoruz
    filtered_data = pd.concat([filtered_data, nan_puanlar])

    # Puansız olanları "dolmadı" olarak işaretleyelim
    filtered_data['En Küçük Puan'] = filtered_data['En Küçük Puan'].replace(np.nan, 'dolmadı')

    return render_template('taban_puanlari.html', filtered_data=filtered_data, universities=universities_list, programs=programs, selected_universite=universite, selected_program=program)

@app.route('/coklu_tercih', methods=['GET', 'POST'])
def coklu_tercih():
    data = pd.read_excel(r'C:\Users\emira\OneDrive\Masaüstü\HTMLdeneme\UniLisans.xlsx')

    # Get unique universities list
    universities_list = data['Üniversite Adı'].unique().tolist()

    if request.method == 'POST':
        universite = request.form.get('universite', '')
        program = request.form.get('program', '')
        puan_turu = request.form.get('puan_turu', '')
        puan_araligi = request.form.get('puan_araligi_min', '')

        # Filter data based on user selections
        filtered_data = filter_data(data, universite, program, puan_turu, puan_araligi)

        # Extract unique program names without content inside parentheses
        programs = filtered_data['Program Adı'].apply(extract_program_name).unique().tolist()

        # Puansız olanları ayrı bir DataFrame'e alıyoruz ve NaN (Not a Number) olarak işaretliyoruz
        nan_puanlar = filtered_data[filtered_data['En Küçük Puan'].isna()]

        # Puansızları çıkarıyoruz ve geri kalanları puanlara göre sıralıyoruz
        filtered_data = filtered_data[~filtered_data['En Küçük Puan'].isna()]
        filtered_data['En Küçük Puan'] = filtered_data['En Küçük Puan'].astype(float)
        filtered_data = filtered_data.sort_values(by=['Puan Türü', 'En Küçük Puan'], ascending=[False, False])

        # Puansızları tekrar ekliyoruz
        filtered_data = pd.concat([filtered_data, nan_puanlar])

        # Puansız olanları "dolmadı" olarak işaretleyelim
        filtered_data['En Küçük Puan'] = filtered_data['En Küçük Puan'].replace(np.nan, 'dolmadı')

    else:
        # If no filter is applied, show the entire data
        filtered_data = data
        programs = data['Program Adı'].apply(extract_program_name).unique().tolist()

    return render_template('coklu_tercih.html', filtered_data=filtered_data, universities=universities_list, programs=programs)

if __name__ == '__main__':
    app.run(debug=True)